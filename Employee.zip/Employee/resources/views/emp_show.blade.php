@extends('welcome')

@section('title')
	<title>Show Employee Details</title>
@endsection

@section('style')
	<style>
		.empdata{
			/*border: 1px solid lightgray;*/
			width: 900px;
			margin-top: 50px;
		}
	</style>
@endsection

@section('content')
	
	<center>
		<h1 class="mt-5 fw-bold text-decoration-underline">Employee Data</h1>
		
		<div class="empdata">
			
		</div>
		<table class="table text-center fs-5">
			<thead>
			<tr>
				<th scope="col">Id</th>
				<th scope="col">Employee Name</th>
				<th scope="col">Address</th>
				<th scope="col">Phone</th>
				<th scope="col" width=280px>Department</th>
				<th scope="col">Salary</th>
				<th scope="col" width="280px">Action</th>
			</tr>
		</thead>
			<?php
			$i=0;
			?>
			@foreach($employees as $employee)
			<tr>
				<td>{{++$i}}</td>
				<td>{{$employee->name}}</td>
				<td>{{$employee->address}}</td>
				<td>{{$employee->phone}}</td>
				<td>{{$employee->department}}</td>
				<td>{{$employee->salary}}</td>
				<td><a class="btn btn-primary" href="{{route('emp.edit',$employee->id)}}">Edit</a></td>
			</tr>
			@endforeach
			</table>
				
	</center>
	

@endsection