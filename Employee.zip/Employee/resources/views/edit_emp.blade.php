@extends('welcome')

@section('title')
	<title>Edit Employee Details</title>
@endsection

@section('style')
	
@endsection

@section('content')

	<div class="">
			<h2 class="text-center fw-bold text-decoration-underline mt-5">Edit Your Employeement Details Here</h2>
			<p class="text-center fs-5 mt-5 text-danger">You can Only Edit Your Address and Phone No.</p><br>
			<div class="d-flex justify-content-center">
				<div class="mt-3 d-flex justify-content-center">

					<div class="fs-4 pt-3 pb-3">
						<form action="{{route('emp.update',$employee->id)}}" method="POST">
							@csrf @method('PUT')
							
							<div class="form-outline mb-4">
								<label>Address: </label>
								<input type="text" style="width:450px; font-size:20px ;" name="address" value="{{$employee->address}}" required class="form-control" placeholder="Address">
							</div>

							<div class="form-outline mb-4">
								<label>Phone: </label>
								<input type="number" id="input" name="phone" value="{{$employee->phone}}" required class="form-control" placeholder="Phone">
							</div>

							<div>
								<input type="submit" name="" value="Update Details" id="input" class="form-control bg-primary text-light fw-bold">
							</div>
						</form>	
					</div>
					
				</div>	
			</div>
			

		</div>

@endsection