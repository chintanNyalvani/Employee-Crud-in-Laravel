@extends('welcome')

@section('title')
	<title>Add Employee Details</title>
@endsection

@section('style')
	<style>
		#input{
			width: 450px;
			height: 50px;
			font-size: 20px;
		}
	</style>
@endsection

@section('content')
	<div>
		<div class="">
			<h2 class="text-center mt-5">Enter Your Employeement Details Here</h2>
			<div class="d-flex justify-content-center">
				<div class="mt-3 d-flex justify-content-center">
					<div class="fs-4 pt-3 pb-3">
						<form action="{{route('emp.store')}}" method="post">
							@csrf
							
							<div class="form-outline mb-4">
								<input type="text" id="input" name="name" required class="form-control " placeholder="Name">

							</div>

							<div class="form-outline mb-4">
								<textarea type="text" style="width:450px; font-size:20px ;" name="address" required class="form-control" placeholder="Address"></textarea>
							</div>

							<div class="form-outline mb-4">
								<input type="number" id="input" name="phone" required class="form-control" placeholder="Phone">
							</div>

							<div class="form-outline mb-4">
								<input type="text" id="input" name="department" required class="form-control" placeholder="Department">
							</div>

							<div class="form-outline mb-4">
								<input type="number" id="input" name="salary" required class="form-control" placeholder="Salary">
							</div>

							<div>
								<input type="submit" name="" value="Add Details" id="input" class="form-control bg-primary text-light fw-bold">
							</div>
						</form>	
					</div>
					
				</div>	
			</div>
			

		</div>
	</div>
@endsection