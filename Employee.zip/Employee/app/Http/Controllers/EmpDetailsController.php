<?php

namespace App\Http\Controllers;

use App\Models\emp_details;
use Illuminate\Http\Request;

class EmpDetailsController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $employees = emp_details::all();
        return view('emp_show',compact('employees'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        return view('emp_add_details');
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $request->validate([
            'name'=>'required',
            'address' => 'required',
            'phone' => 'required',
            'department' => 'required',
            'salary' => 'required'
        ]);
        emp_details::create($request->all());
        return redirect()->route('emp.index')->with('success','Details Added successfully');
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Models\emp_details  $emp_details
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        // $empDetails = emp_details::findOrFail($id);
        // return view('emp_show',compact('empDetails'));
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Models\emp_details  $emp_details
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        $employee = emp_details::findOrFail($id);
        return view('edit_emp',compact('employee'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Models\emp_details  $emp_details
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        echo $id;
        $request->validate([
           
            'address' => 'required',
            'phone' => 'required'
        ]);
        $employee = emp_details::findOrFail($id);
        if($employee){
            $employee->update($request->all());
            return redirect()->route('emp.index')->with('success','Details Updated successfully');
        }else{
            return redirect()->route('emp.index')->with('success','Details Updated successfully');
        }
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Models\emp_details  $emp_details
     * @return \Illuminate\Http\Response
     */
    public function destroy(emp_details $emp_details)
    {
        //
    }
}
