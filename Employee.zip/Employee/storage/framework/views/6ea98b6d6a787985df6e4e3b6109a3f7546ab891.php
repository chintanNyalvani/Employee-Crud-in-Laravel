

<?php $__env->startSection('title'); ?>
	<title>Edit Employee Details</title>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('style'); ?>
	
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

	<div class="">
			<h2 class="text-center fw-bold text-decoration-underline mt-5">Enter Your Employeement Details Here</h2>
			<p class="text-center fs-5 mt-5 text-danger">You can Only Edit Your Address and Phone No.</p><br>
			<div class="d-flex justify-content-center">
				<div class="mt-3 d-flex justify-content-center">

					<div class="fs-4 pt-3 pb-3">
						<form action="<?php echo e(route('emp.update',$employee->id)); ?>" method="POST">
							<?php echo csrf_field(); ?> <?php echo method_field('PUT'); ?>
							
							<div class="form-outline mb-4">
								<label>Address: </label>
								<input type="text" style="width:450px; font-size:20px ;" name="address" value="<?php echo e($employee->address); ?>" required class="form-control" placeholder="Address">
							</div>

							<div class="form-outline mb-4">
								<label>Phone: </label>
								<input type="number" id="input" name="phone" value="<?php echo e($employee->phone); ?>" required class="form-control" placeholder="Phone">
							</div>

							<div>
								<input type="submit" name="" value="Update Details" id="input" class="form-control bg-primary text-light fw-bold">
							</div>
						</form>	
					</div>
					
				</div>	
			</div>
			

		</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('welcome', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Laravel\Employee\resources\views/edit_emp.blade.php ENDPATH**/ ?>